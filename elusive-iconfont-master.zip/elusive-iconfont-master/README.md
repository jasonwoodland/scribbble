Elusive-Iconfont
================

The Elusive Iconfont is an icons webfont, optimized for use with twitter's bootstrap.

For examples & usage see http://shoestrap.org/downloads/elusive-icons-webfont/

Licence: [SIL](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
